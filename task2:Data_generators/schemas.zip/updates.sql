UPDATE Teachers SET teacher_address = 'Gdynia Derdowskiego 35 a/8' WHERE teacher_ID = 1
UPDATE Teachers SET teacher_address = 'Gdynia Kaszubska 49 61 c/8' WHERE teacher_ID = 5
UPDATE Teachers SET teacher_address = 'Gdynia Komuny Paryskiej 42 a/5' WHERE teacher_ID = 9
UPDATE Teachers SET teacher_address = 'Gdynia Morska 93 b/4' WHERE teacher_ID = 13
UPDATE Teachers SET teacher_address = 'Gdynia Kaszubska 49 82 a/5' WHERE teacher_ID = 17
UPDATE Teachers SET teacher_address = 'Gdynia Akademicka 12 a/1' WHERE teacher_ID = 21
UPDATE Teachers SET teacher_address = 'Gdynia Wiczlina 80 a/8' WHERE teacher_ID = 25
UPDATE Teachers SET teacher_address = 'Gdynia Jana z Kolna 91 a/9' WHERE teacher_ID = 29


UPDATE Students SET student_address = 'Gdynia Wiejska 42 a/3' WHERE student_ID = 1
UPDATE Students SET student_address = 'Gdynia Akademicka 42 a/5' WHERE student_ID = 16
UPDATE Students SET student_address = 'Gdynia Wladyslawa IV 65 c/1' WHERE student_ID = 31
UPDATE Students SET student_address = 'Gdynia Abrahama 84 b/5' WHERE student_ID = 46
UPDATE Students SET student_address = 'Gdynia Hutnicza 42 c/5' WHERE student_ID = 61
UPDATE Students SET student_address = 'Gdynia Wiczlina 25 b/8' WHERE student_ID = 76
UPDATE Students SET student_address = 'Gdynia Hutnicza 85 a/6' WHERE student_ID = 91
UPDATE Students SET student_address = 'Gdynia Slowackiego 15 a/6' WHERE student_ID = 106
UPDATE Students SET student_address = 'Gdynia Wzgorze Sw. Maksymiliana 12 a/2' WHERE student_ID = 121
UPDATE Students SET student_address = 'Gdynia Kaszubska 49 82 c/2' WHERE student_ID = 136
UPDATE Students SET student_address = 'Gdynia Pucka 58 c/7' WHERE student_ID = 151
UPDATE Students SET student_address = 'Gdynia Komuny Paryskiej 58 c/3' WHERE student_ID = 166
UPDATE Students SET student_address = 'Gdynia Pucka 12 c/7' WHERE student_ID = 181
UPDATE Students SET student_address = 'Gdynia Kosciuszki 19 b/2' WHERE student_ID = 196
UPDATE Students SET student_address = 'Gdynia Akademicka 34 a/9' WHERE student_ID = 211
UPDATE Students SET student_address = 'Gdynia Kielecka 30 b/9' WHERE student_ID = 226
UPDATE Students SET student_address = 'Gdynia Kosciuszki 73 c/6' WHERE student_ID = 241
UPDATE Students SET student_address = 'Gdynia Paderewskiego 8 c/9' WHERE student_ID = 256
UPDATE Students SET student_address = 'Gdynia Chopina 66 33 c/6' WHERE student_ID = 271
UPDATE Students SET student_address = 'Gdynia Polska 14 a/3' WHERE student_ID = 286
UPDATE Students SET student_address = 'Gdynia Swietokrzyska 7 a/3' WHERE student_ID = 301
UPDATE Students SET student_address = 'Gdynia Komuny Paryskiej 11 b/9' WHERE student_ID = 316
UPDATE Students SET student_address = 'Gdynia Abrahama 75 a/8' WHERE student_ID = 331
UPDATE Students SET student_address = 'Gdynia Powstania Styczniowego 95 b/5' WHERE student_ID = 346