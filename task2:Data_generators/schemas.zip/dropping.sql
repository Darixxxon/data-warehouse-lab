DROP TABLE Attendance
DROP TABLE Classes
DROP TABLE Tests
DROP TABLE Courses
Drop Table Students
DROP TABLE Groups
DROP TABLE Teachers
 